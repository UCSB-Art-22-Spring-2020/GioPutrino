// gio putrino
// 26 May 2020

function setup() {
  createCanvas(500, 500);
}

function draw() {
  strokeWeight(10); // 10 pixel thick stroke
  stroke(20, 107, 61); // green outline
  noFill(); // remove fill from shape
  triangle(25, 25, 125, 225, 225, 25); // draw triangle
  // should be in the top left quadrant (Q1)

  stroke(20, 107, 61); // green line
  line(25, 75, 236, 75); // goes through triangle in Q1

  strokeWeight(10); // 10 pixel thick stroke
  stroke(255, 255, 0); // yellow outline
  noFill(); // remove fill from shape
  triangle(275, 225, 375, 25, 475, 225); // draw triangle
  // should be in the top right quadrant (Q2)

  stroke(255, 255, 0); // yellow line
  line(262, 175, 487, 175); // goes through triangle in Q2

  strokeWeight(10); // 10 pixel thick stroke
  stroke(16, 64, 135); // blue outline
  noFill(); // remove fill from shape
  triangle(275, 275, 375, 475, 475, 275); // draw triangle
  // should be in the bottom right quadrant (Q3)

  strokeWeight(10); // 10 pixel thick stroke
  stroke(163, 21, 16); // red outline
  noFill(); // remove fill from shape
  triangle(25, 475, 125, 275, 225, 475); // draw triangle
  // should be in the bottom left quadrant (Q4)

  //for a trail of color
  if (mouseX < 250 && mouseY < 250) { // should be in top left quadrant
    stroke(142, 204, 106, 128); // leaf green
  } else if (mouseX > 250 && mouseY < 250) { // should be in top right quadrant
    stroke(255, 237, 97, 128); // pale yellow
  } else if (mouseX > 250 && mouseY > 250) { // should be in the bottom right quadrant
    stroke(22, 167, 224, 128); // sky blue
  } else if (mouseX < 250 && mouseY > 250) { // should be in the bottom left quadrant
    stroke(252, 63, 63, 128); //poppy red
  }

  strokeWeight(50); // 50 pixel thick stroke 
  point(mouseX, mouseY); // point follows mouse 
}